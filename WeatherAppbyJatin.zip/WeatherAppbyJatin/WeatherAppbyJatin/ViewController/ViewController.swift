//
//  ViewController.swift
//  WeatherAppbyJatin
//
//  Created by Jatin Gupta on 01/12/22.
//

import UIKit
import SpriteKit
import CoreLocation
import Lottie

class ViewController: UIViewController {
    @IBOutlet weak var conditionImage: UIImageView!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var conditionsLabel: UILabel!
    
    @IBOutlet weak var hazeView: Haze!
    @IBOutlet weak var snowView: Snow!
    @IBOutlet weak var cloudyView: Cloudy!
    @IBOutlet weak var smokeView: Smoke!
    @IBOutlet weak var rainView: Rainfall!
    @IBOutlet weak var windSpeed: UILabel!
    @IBOutlet weak var humidity: UILabel!
    
    @IBOutlet weak var riseLabel: UILabel!
    @IBOutlet weak var setLabel: UILabel!
    
    @IBOutlet weak var searchTextField: UITextField!
    var weathermanger = WeatherManager()
    let locationManager = CLLocationManager()
    let defaults = UserDefaults.standard
    var animationView: LottieAnimationView?
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        weathermanger.delegate = self
        searchTextField.delegate = self
        searchTextField.autocapitalizationType = .words
        searchTextField.keyboardType = .alphabet
        rainView.isHidden = true
        smokeView.isHidden = true
        cloudyView.isHidden = true
        snowView.isHidden = true
        hazeView.isHidden = true
        animationView?.isHidden = true
        
        if let lat = defaults.object(forKey: "latitude") as? Double{
            if let lon = defaults.object(forKey: "longitude") as? Double {
                weathermanger.fetchWeather(lat: lat, lon: lon)
            }
        } else {
            locationManager.requestLocation()
        }
    }
    
    func hazeto() {
        animationView = .init(name: "cloudsy")
//        animationView!.frame = view.bounds
        animationView!.frame = CGRect(x: 0, y: 100, width: view.bounds.width, height: view.bounds.height - 340)
        animationView?.loopMode = .loop
        view.addSubview(animationView!)
        animationView?.play()
        //        animationView?.
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    @IBAction func locationPressed(_ sender: UIButton) {
        locationManager.requestLocation()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

extension ViewController: UITextFieldDelegate {
    
    @IBAction func searchPressed(_ sender: UIButton) {
        searchTextField.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        searchTextField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if textField.text != "" {
            return true
        } else {
            textField.placeholder = "Type something"
            return true
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if let city = searchTextField.text {
            if city.count >= 1 {
                weathermanger.fetchWeather(cityName: city)
            } else {
                locationManager.requestLocation()
            }
        }
        searchTextField.text = ""
    }
}

extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        locationManager.stopUpdatingLocation()
        if let location = locations.last {
            let lat = location.coordinate.latitude
            let lon = location.coordinate.longitude
            self.defaults.set(lat, forKey: "latitude")
            self.defaults.set(lon, forKey: "longitude")
            weathermanger.fetchWeather(lat: lat, lon: lon)
        }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("error")
    }
    
}

extension ViewController: WeatherManagerDelegate {
    func didUpdateWeather(_ weatherManager: WeatherManager, weather: WeatherModel) {
        DispatchQueue.main.async { [self] in
            if weather.description == "smoke"{
                smokeView.isHidden = false
                rainView.isHidden = true
                cloudyView.isHidden = true
                snowView.isHidden = true
                hazeView.isHidden = true
                animationView?.isHidden = true
            } else if weather.description == "rain" {
                smokeView.isHidden = true
                rainView.isHidden = false
                cloudyView.isHidden = true
                snowView.isHidden = true
                hazeView.isHidden = true
                animationView?.isHidden = true
            } else if weather.description == "clear sky" {
                rainView.isHidden = true
                smokeView.isHidden = true
                cloudyView.isHidden = true
                snowView.isHidden = true
                hazeView.isHidden = true
                animationView?.isHidden = true
            } else if weather.description == "scattered clouds" {
                rainView.isHidden = true
                smokeView.isHidden = true
                cloudyView.isHidden = false
                snowView.isHidden = true
                hazeView.isHidden = true
                animationView?.isHidden = true
            } else if weather.description == "overcast clouds" {
                rainView.isHidden = true
                smokeView.isHidden = true
                cloudyView.isHidden = false
                snowView.isHidden = true
                hazeView.isHidden = true
                animationView?.isHidden = true
            } else if weather.description == "broken clouds" {
                rainView.isHidden = true
                smokeView.isHidden = true
                cloudyView.isHidden = false
                snowView.isHidden = true
                hazeView.isHidden = true
                animationView?.isHidden = true
            } else if weather.description == "snow" {
                rainView.isHidden = true
                smokeView.isHidden = true
                cloudyView.isHidden = true
                snowView.isHidden = false
                hazeView.isHidden = true
                animationView?.isHidden = true
            } else if weather.description == "light rain" {
                smokeView.isHidden = true
                rainView.isHidden = false
                cloudyView.isHidden = true
                snowView.isHidden = true
                hazeView.isHidden = true
                animationView?.isHidden = true
            } else if weather.description == "haze" {
                rainView.isHidden = true
                smokeView.isHidden = true
                cloudyView.isHidden = true
                snowView.isHidden = true
                hazeView.isHidden = true
                hazeto()
            } else if weather.description == "few clouds" {
                rainView.isHidden = true
                smokeView.isHidden = true
                cloudyView.isHidden = true
                snowView.isHidden = true
                hazeView.isHidden = true
                hazeto()
            } else {
                rainView.isHidden = true
                smokeView.isHidden = true
                cloudyView.isHidden = true
                snowView.isHidden = true
                hazeView.isHidden = true
                animationView?.isHidden = true
            }
            self.temperatureLabel.text = weather.temperatureString
            self.windSpeed.text = weather.windSpeedString
            self.humidity.text = weather.humidityString
            self.conditionsLabel.text = weather.description
            self.cityLabel.text = weather.cityName
            self.riseLabel.text = weather.sunRiseString
            self.setLabel.text = weather.sunSetString
            self.conditionImage.image = UIImage(systemName: weather.conditionName)
        }
        
    }
    func didFailWithError(error: Error) {
        locationManager.requestLocation()
    }
}

class Rainfall: SKView {
    override func didMoveToSuperview() {
        let scene  = SKScene(size: self.frame.size)
        scene.backgroundColor = UIColor.clear
        self.presentScene(scene)
        
        self.allowsTransparency = true
        self.backgroundColor = UIColor.clear
        
        if let particles = SKEmitterNode(fileNamed: "Rain.sks") {
            particles.position = CGPoint(
                x: self.frame.size.width / 2,
                y: self.frame.size.height/2 + 250
            )
            
            particles.particlePositionRange = CGVector(dx: self.bounds.size.width, dy: 0)
            
            addChild(for: scene, with: particles)
            
        }
    }
    
    private func addChild(for scene: SKScene, with child: SKEmitterNode) {
        scene.addChild(child)
    }
}

class Smoke: SKView {
    override func didMoveToSuperview() {
        let scene  = SKScene(size: self.frame.size)
        scene.backgroundColor = UIColor.clear
        self.presentScene(scene)
        
        self.allowsTransparency = true
        self.backgroundColor = UIColor.clear
        
        if let particles = SKEmitterNode(fileNamed: "Smoke.sks") {
            particles.position = CGPoint(
                x: self.frame.size.width / 2,
                y: self.frame.size.height/2 + 200
            )
            
            particles.particlePositionRange = CGVector(dx: self.bounds.size.width, dy: 0)
            
            addChild(for: scene, with: particles)
            
        }
    }
    
    private func addChild(for scene: SKScene, with child: SKEmitterNode) {
        scene.addChild(child)
    }
}
class Cloudy: SKView {
    override func didMoveToSuperview() {
        let scene  = SKScene(size: self.frame.size)
        scene.backgroundColor = UIColor.clear
        self.presentScene(scene)
        
        self.allowsTransparency = true
        self.backgroundColor = UIColor.clear
        
        if let particles = SKEmitterNode(fileNamed: "Cloudy.sks") {
            particles.position = CGPoint(
                x: self.frame.size.width / 2,
                y: self.frame.size.height/2 + 200
            )
            
            particles.particlePositionRange = CGVector(dx: self.bounds.size.width, dy: 0)
            
            addChild(for: scene, with: particles)
            
        }
    }
    
    private func addChild(for scene: SKScene, with child: SKEmitterNode) {
        scene.addChild(child)
    }
}

class Snow: SKView {
    override func didMoveToSuperview() {
        let scene  = SKScene(size: self.frame.size)
        scene.backgroundColor = UIColor.clear
        self.presentScene(scene)
        
        self.allowsTransparency = true
        self.backgroundColor = UIColor.clear
        
        if let particles = SKEmitterNode(fileNamed: "Snow.sks") {
            particles.position = CGPoint(
                x: self.frame.size.width / 2,
                y: self.frame.size.height
            )
            
            particles.particlePositionRange = CGVector(dx: self.bounds.size.width, dy: 0)
            
            addChild(for: scene, with: particles)
            
        }
    }
    
    private func addChild(for scene: SKScene, with child: SKEmitterNode) {
        scene.addChild(child)
    }
}

class Haze: SKView {
    override func didMoveToSuperview() {
        let scene  = SKScene(size: self.frame.size)
        scene.backgroundColor = UIColor.clear
        self.presentScene(scene)
        
        self.allowsTransparency = true
        self.backgroundColor = UIColor.clear
        
        if let particles = SKEmitterNode(fileNamed: "Haze.sks") {
            particles.position = CGPoint(
                x: self.frame.size.width / 2,
                y: self.frame.size.height/2 + 300
            )
            
            particles.particlePositionRange = CGVector(dx: self.bounds.size.width, dy: 0)
            
            addChild(for: scene, with: particles)
            
        }
    }
    
    private func addChild(for scene: SKScene, with child: SKEmitterNode) {
        scene.addChild(child)
    }
}
