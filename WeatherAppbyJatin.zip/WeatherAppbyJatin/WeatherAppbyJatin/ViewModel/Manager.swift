//
//  Manager.swift
//  WeatherAppbyJatin
//
//  Created by Jatin Gupta on 01/12/22.
//

import Foundation
import CoreLocation
import Alamofire

protocol WeatherManagerDelegate {
    func didUpdateWeather(_ weatherManager: WeatherManager, weather: WeatherModel)
    func didFailWithError(error: Error)
}
struct WeatherManager {
    var delegate: WeatherManagerDelegate?
    
    private let apiKey = "2757c8731ab7add6c3a3d1c0ecb15865"
    private let url = "https://api.openweathermap.org/data/2.5/weather?&appid"
    
    func fetchWeather(cityName: String){
        let weatherURL = "\(url)=\(apiKey)&q=\(cityName)&units=metric"
        print(weatherURL)
        performRequestWithAF(with: weatherURL)
    }
    func fetchWeather(lat: CLLocationDegrees, lon: CLLocationDegrees) {
        let weatherURL = "\(url)=\(apiKey)&lat=\(lat)&lon=\(lon)&units=metric"
        performRequestWithAF(with: weatherURL)
    }
    
    func performRequestWithAF (with urlString: String) {

        AF.request(urlString).response {
            response in
            
            if let error = response.error {
                if error != nil {
                    return
                }
            }
            if let safeData = response.data {
                if let weather = self.parseJSON(weatherData: safeData) {
                    self.delegate?.didUpdateWeather(self, weather: weather)
                }
            }
        }
    }


//func performRequest(with urlString: String) {
//    if let url = URL(string: urlString) {
//        let session = URLSession(configuration: .default)
//        let task = session.dataTask(with: url) { data, response, error in
//            if error != nil {
//                return
//            }
//            if let safeData = data {
//                if let weather = self.parseJSON(weatherData: safeData) {
//                    self.delegate?.didUpdateWeather(self, weather: weather)
//                }
//            }
//        }
//        task.resume()
//    }
//}
func parseJSON(weatherData: Data) -> WeatherModel? {
    let decoder = JSONDecoder()
    do {
        let decodedData = try decoder.decode(WeatherData.self, from: weatherData)
        let weather = WeatherModel(sunRiseSeconds: decodedData.sys.sunrise, sunSetSeconds: decodedData.sys.sunset, description: decodedData.weather[0].description, cityName: decodedData.name, conditionID: decodedData
            .weather[0].id, temperature: decodedData.main.temp, humidity: decodedData.main.humidity, wind: decodedData.wind.speed)
        return weather
    } catch {
        delegate?.didFailWithError(error: error)
        return nil
    }
}
}

