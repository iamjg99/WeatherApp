//
//  ModelData.swift
//  WeatherAppbyJatin
//
//  Created by Jatin Gupta on 01/12/22.
//

import Foundation

struct WeatherData : Decodable {
    let name: String
    let weather: [WeatherState]
    let main: Main
    let sys: CityTime
    let wind: Wind
}

struct Main : Decodable {
    let temp: Double
    let humidity: Int
}

struct WeatherState : Decodable{
    let id: Int
    let description: String
}

struct CityTime: Decodable {
    let sunrise: TimeInterval
    let sunset: TimeInterval
}
struct Wind: Decodable {
    let speed: Double
}
