//
//  Model.swift
//  WeatherAppbyJatin
//
//  Created by Jatin Gupta on 01/12/22.
//

import Foundation

struct WeatherModel {

    let sunRiseSeconds: TimeInterval
    var sunRiseString: String {
        let time = Date(timeIntervalSince1970: sunRiseSeconds)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        return dateFormatter.string(from: time)
    }

    let sunSetSeconds: TimeInterval
    var sunSetString: String {
        let time = Date(timeIntervalSince1970: sunSetSeconds)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        return dateFormatter.string(from: time)
    }

    let description: String
    let cityName: String
    let conditionID: Int
    var conditionName: String {
        
        switch (conditionID/100) {
        case 2:
            return "cloud.bolt.rain"
        case 3:
            return "cloud.drizzle"
        case 5:
            return "cloud.rain"
        case 6:
            return "cloud.snow"
        case 7:
            return "sun.dust"
        case 8:
            if conditionID == 800 {
                return "sun.max"
            }
            return "cloud.sun"
        default:
            return "xxx"
        }
    }

    let temperature: Double
    var temperatureString: String {
        String(format: "%0.0f", temperature)
    }
    let humidity: Int
    var humidityString: String {
        return "\(humidity)%"
    }
    let wind: Double
    var windSpeedString: String {
        String(format: "%0.0fkm/h", wind)
    }
    
}
